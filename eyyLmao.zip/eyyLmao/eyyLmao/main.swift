//
//  swift?
//
//
//  more like slow
//
//

import Foundation

print("\n")

print("wat year is it?")




var validInput : Bool
repeat {
    
    
    
    var eyy = readLine(stripNewline: true)
    
    
    validInput = true
    
    
    if let year = eyy {
        
        
        print("")
        
    }
    
    
    var year = Float(eyy!)

    

    
    
    
    
    
} while validInput == false



